rhub::check_on_linux()
rhub::check_on_windows()
rhub::check_on_macos()
