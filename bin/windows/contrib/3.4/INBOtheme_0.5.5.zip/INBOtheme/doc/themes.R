## ----knitr, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  echo = FALSE,
  message = FALSE,
  warning = FALSE,
  fig.width  = 7.2,
  fig.height = 5
)

## ----initialise, echo = TRUE---------------------------------------------
library(ggplot2)
library(INBOtheme)

## ----create_simple_dataset-----------------------------------------------
pp <- function(n) {
  df <- expand.grid(
    x = seq_len(n),
    y = seq_len(n)
  )
  df$z <- df$x + df$y
  df
}

df <- data.frame(
  trt = factor(c(1, 1, 2, 2)),
  resp = c(1, 5, 3, 4),
  group = factor(c(1, 2, 1, 2)),
  se = c(0.1, 0.3, 0.3, 0.2)
)

testgrid <- expand.grid(x = 1:4, y = 1:4)
testgrid$z <- factor((testgrid$x - 1) * 4 + testgrid$y)

## ----default_theme-------------------------------------------------------
update_geom_defaults("text", list(size = 2.5))

## ------------------------------------------------------------------------
demo_palette(inbo.2015.colours())

## ------------------------------------------------------------------------
demo_palette(vlaanderen.2015.colours())

## ------------------------------------------------------------------------
demo_palette(INBO.colours())

## ----set_theme_inbo, echo = TRUE-----------------------------------------
theme_set(theme_inbo())
switchColour(inbo.steun.blauw)

## ------------------------------------------------------------------------
cancer <- esoph
cancer$Age <- cancer$agegp
cancer$Alcohol <- cancer$alcgp
cancer$Tabacco <- cancer$tobgp
cancer$Proportion <- cancer$ncases / (cancer$ncases + cancer$ncontrols)

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Age, y = Proportion)) +
  geom_boxplot() +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Age, y = Proportion)) +
  geom_violin()

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram()

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram() +
  facet_wrap(~Age, scales = "free") +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram(aes(fill = ..count..)) +
  facet_grid(Alcohol ~ Tabacco, scales = "free") +
  scale_fill_gradient() +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram(aes(fill = ..count..)) +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = carat, y = depth, colour = price)) +
  geom_point() +
  scale_colour_gradient()

## ------------------------------------------------------------------------
selection <- table(msleep$order)
selection <- names(selection)[selection > 3]
ggplot(
  subset(msleep, order %in% selection),
  aes(x = bodywt, y = sleep_total, label = name)
) +
  geom_point() +
  geom_text() +
  facet_wrap(~order, scales = "free") +
  scale_x_continuous(expand = c(0.5, 0.01))

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, fill = cut)) +
  geom_histogram()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = log10(price), fill = cut)) +
  geom_histogram() +
  facet_wrap(~ clarity)

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, colour = cut)) +
  geom_density()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, fill = cut)) +
  geom_density(alpha = 0.2)

## ------------------------------------------------------------------------
ggplot(mtcars, aes(x = wt, y = mpg, colour = factor(cyl), fill = factor(cyl))) +
  geom_point() +
  geom_smooth(method = "lm")

## ------------------------------------------------------------------------
ggplot(mtcars, aes(x = wt, y = mpg, colour = factor(cyl), fill = factor(cyl))) +
  geom_smooth(method = "lm", aes(fill = NULL, colour = NULL)) +
  geom_point() +
  geom_smooth(method = "lm") +
  ggtitle("Title", "Subtitle")

## ------------------------------------------------------------------------
ggplot(pp(100), aes(x = x, y = y, fill = z)) +
  geom_tile() +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8) +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8) +
  scale_fill_gradient2(midpoint = 20)

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8)

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, colour = z)) +
  geom_point() +
  scale_colour_gradient()

## ------------------------------------------------------------------------
ggplot(
  df,
  aes(colour = group, y = resp, x = trt, ymax = resp + se, ymin = resp - se)
) +
  geom_point() +
  geom_errorbar(width = 0.2)

## ------------------------------------------------------------------------
ggplot(testgrid, aes(x = x, y = y, fill = z, label = z)) +
  geom_tile(width = 0.7, height = 0.7) +
  geom_text() +
  coord_fixed()

## ----set_theme_inbo_transparant, echo = TRUE-----------------------------
theme_set(theme_inbo(transparent = TRUE))
switchColour(inbo.steun.blauw)

## ------------------------------------------------------------------------
cancer <- esoph
cancer$Age <- cancer$agegp
cancer$Alcohol <- cancer$alcgp
cancer$Tabacco <- cancer$tobgp
cancer$Proportion <- cancer$ncases / (cancer$ncases + cancer$ncontrols)

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Age, y = Proportion)) +
  geom_boxplot() +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Age, y = Proportion)) +
  geom_violin()

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram()

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram() +
  facet_wrap(~Age, scales = "free") +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram(aes(fill = ..count..)) +
  facet_grid(Alcohol ~ Tabacco, scales = "free") +
  scale_fill_gradient() +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram(aes(fill = ..count..)) +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = carat, y = depth, colour = price)) +
  geom_point() +
  scale_colour_gradient()

## ------------------------------------------------------------------------
selection <- table(msleep$order)
selection <- names(selection)[selection > 3]
ggplot(
  subset(msleep, order %in% selection),
  aes(x = bodywt, y = sleep_total, label = name)
) +
  geom_point() +
  geom_text() +
  facet_wrap(~order, scales = "free") +
  scale_x_continuous(expand = c(0.5, 0.01))

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, fill = cut)) +
  geom_histogram()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = log10(price), fill = cut)) +
  geom_histogram() +
  facet_wrap(~ clarity)

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, colour = cut)) +
  geom_density()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, fill = cut)) +
  geom_density(alpha = 0.2)

## ------------------------------------------------------------------------
ggplot(mtcars, aes(x = wt, y = mpg, colour = factor(cyl), fill = factor(cyl))) +
  geom_point() +
  geom_smooth(method = "lm")

## ------------------------------------------------------------------------
ggplot(mtcars, aes(x = wt, y = mpg, colour = factor(cyl), fill = factor(cyl))) +
  geom_smooth(method = "lm", aes(fill = NULL, colour = NULL)) +
  geom_point() +
  geom_smooth(method = "lm") +
  ggtitle("Title", "Subtitle")

## ------------------------------------------------------------------------
ggplot(pp(100), aes(x = x, y = y, fill = z)) +
  geom_tile() +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8) +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8) +
  scale_fill_gradient2(midpoint = 20)

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8)

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, colour = z)) +
  geom_point() +
  scale_colour_gradient()

## ------------------------------------------------------------------------
ggplot(
  df,
  aes(colour = group, y = resp, x = trt, ymax = resp + se, ymin = resp - se)
) +
  geom_point() +
  geom_errorbar(width = 0.2)

## ------------------------------------------------------------------------
ggplot(testgrid, aes(x = x, y = y, fill = z, label = z)) +
  geom_tile(width = 0.7, height = 0.7) +
  geom_text() +
  coord_fixed()

## ----set_theme_vlaanderen2015, echo = TRUE-------------------------------
theme_set(theme_vlaanderen2015())
switchColour(vl.darkyellow)

## ------------------------------------------------------------------------
cancer <- esoph
cancer$Age <- cancer$agegp
cancer$Alcohol <- cancer$alcgp
cancer$Tabacco <- cancer$tobgp
cancer$Proportion <- cancer$ncases / (cancer$ncases + cancer$ncontrols)

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Age, y = Proportion)) +
  geom_boxplot() +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Age, y = Proportion)) +
  geom_violin()

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram()

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram() +
  facet_wrap(~Age, scales = "free") +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram(aes(fill = ..count..)) +
  facet_grid(Alcohol ~ Tabacco, scales = "free") +
  scale_fill_gradient() +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram(aes(fill = ..count..)) +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = carat, y = depth, colour = price)) +
  geom_point() +
  scale_colour_gradient()

## ------------------------------------------------------------------------
selection <- table(msleep$order)
selection <- names(selection)[selection > 3]
ggplot(
  subset(msleep, order %in% selection),
  aes(x = bodywt, y = sleep_total, label = name)
) +
  geom_point() +
  geom_text() +
  facet_wrap(~order, scales = "free") +
  scale_x_continuous(expand = c(0.5, 0.01))

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, fill = cut)) +
  geom_histogram()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = log10(price), fill = cut)) +
  geom_histogram() +
  facet_wrap(~ clarity)

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, colour = cut)) +
  geom_density()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, fill = cut)) +
  geom_density(alpha = 0.2)

## ------------------------------------------------------------------------
ggplot(mtcars, aes(x = wt, y = mpg, colour = factor(cyl), fill = factor(cyl))) +
  geom_point() +
  geom_smooth(method = "lm")

## ------------------------------------------------------------------------
ggplot(mtcars, aes(x = wt, y = mpg, colour = factor(cyl), fill = factor(cyl))) +
  geom_smooth(method = "lm", aes(fill = NULL, colour = NULL)) +
  geom_point() +
  geom_smooth(method = "lm") +
  ggtitle("Title", "Subtitle")

## ------------------------------------------------------------------------
ggplot(pp(100), aes(x = x, y = y, fill = z)) +
  geom_tile() +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8) +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8) +
  scale_fill_gradient2(midpoint = 20)

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8)

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, colour = z)) +
  geom_point() +
  scale_colour_gradient()

## ------------------------------------------------------------------------
ggplot(
  df,
  aes(colour = group, y = resp, x = trt, ymax = resp + se, ymin = resp - se)
) +
  geom_point() +
  geom_errorbar(width = 0.2)

## ------------------------------------------------------------------------
ggplot(testgrid, aes(x = x, y = y, fill = z, label = z)) +
  geom_tile(width = 0.7, height = 0.7) +
  geom_text() +
  coord_fixed()

## ----set_theme_vlaanderen2015_transparant, echo = TRUE-------------------
theme_set(theme_vlaanderen2015(transparent = TRUE))
switchColour(vl.darkyellow)

## ------------------------------------------------------------------------
cancer <- esoph
cancer$Age <- cancer$agegp
cancer$Alcohol <- cancer$alcgp
cancer$Tabacco <- cancer$tobgp
cancer$Proportion <- cancer$ncases / (cancer$ncases + cancer$ncontrols)

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Age, y = Proportion)) +
  geom_boxplot() +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Age, y = Proportion)) +
  geom_violin()

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram()

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram() +
  facet_wrap(~Age, scales = "free") +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram(aes(fill = ..count..)) +
  facet_grid(Alcohol ~ Tabacco, scales = "free") +
  scale_fill_gradient() +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram(aes(fill = ..count..)) +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = carat, y = depth, colour = price)) +
  geom_point() +
  scale_colour_gradient()

## ------------------------------------------------------------------------
selection <- table(msleep$order)
selection <- names(selection)[selection > 3]
ggplot(
  subset(msleep, order %in% selection),
  aes(x = bodywt, y = sleep_total, label = name)
) +
  geom_point() +
  geom_text() +
  facet_wrap(~order, scales = "free") +
  scale_x_continuous(expand = c(0.5, 0.01))

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, fill = cut)) +
  geom_histogram()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = log10(price), fill = cut)) +
  geom_histogram() +
  facet_wrap(~ clarity)

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, colour = cut)) +
  geom_density()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, fill = cut)) +
  geom_density(alpha = 0.2)

## ------------------------------------------------------------------------
ggplot(mtcars, aes(x = wt, y = mpg, colour = factor(cyl), fill = factor(cyl))) +
  geom_point() +
  geom_smooth(method = "lm")

## ------------------------------------------------------------------------
ggplot(mtcars, aes(x = wt, y = mpg, colour = factor(cyl), fill = factor(cyl))) +
  geom_smooth(method = "lm", aes(fill = NULL, colour = NULL)) +
  geom_point() +
  geom_smooth(method = "lm") +
  ggtitle("Title", "Subtitle")

## ------------------------------------------------------------------------
ggplot(pp(100), aes(x = x, y = y, fill = z)) +
  geom_tile() +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8) +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8) +
  scale_fill_gradient2(midpoint = 20)

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8)

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, colour = z)) +
  geom_point() +
  scale_colour_gradient()

## ------------------------------------------------------------------------
ggplot(
  df,
  aes(colour = group, y = resp, x = trt, ymax = resp + se, ymin = resp - se)
) +
  geom_point() +
  geom_errorbar(width = 0.2)

## ------------------------------------------------------------------------
ggplot(testgrid, aes(x = x, y = y, fill = z, label = z)) +
  geom_tile(width = 0.7, height = 0.7) +
  geom_text() +
  coord_fixed()

## ----set_theme_elsevier, echo = TRUE-------------------------------------
theme_set(theme_elsevier(12))
switchColour("black")

## ------------------------------------------------------------------------
cancer <- esoph
cancer$Age <- cancer$agegp
cancer$Alcohol <- cancer$alcgp
cancer$Tabacco <- cancer$tobgp
cancer$Proportion <- cancer$ncases / (cancer$ncases + cancer$ncontrols)

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Age, y = Proportion)) +
  geom_boxplot() +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Age, y = Proportion)) +
  geom_violin()

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram()

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram() +
  facet_wrap(~Age, scales = "free") +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram(aes(fill = ..count..)) +
  facet_grid(Alcohol ~ Tabacco, scales = "free") +
  scale_fill_gradient() +
  ggtitle("cancer dataset")

## ------------------------------------------------------------------------
ggplot(cancer, aes(x = Proportion)) +
  geom_histogram(aes(fill = ..count..)) +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = carat, y = depth, colour = price)) +
  geom_point() +
  scale_colour_gradient()

## ------------------------------------------------------------------------
selection <- table(msleep$order)
selection <- names(selection)[selection > 3]
ggplot(
  subset(msleep, order %in% selection),
  aes(x = bodywt, y = sleep_total, label = name)
) +
  geom_point() +
  geom_text() +
  facet_wrap(~order, scales = "free") +
  scale_x_continuous(expand = c(0.5, 0.01))

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, fill = cut)) +
  geom_histogram()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = log10(price), fill = cut)) +
  geom_histogram() +
  facet_wrap(~ clarity)

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, colour = cut)) +
  geom_density()

## ------------------------------------------------------------------------
ggplot(diamonds, aes(x = price, fill = cut)) +
  geom_density(alpha = 0.2)

## ------------------------------------------------------------------------
ggplot(mtcars, aes(x = wt, y = mpg, colour = factor(cyl), fill = factor(cyl))) +
  geom_point() +
  geom_smooth(method = "lm")

## ------------------------------------------------------------------------
ggplot(mtcars, aes(x = wt, y = mpg, colour = factor(cyl), fill = factor(cyl))) +
  geom_smooth(method = "lm", aes(fill = NULL, colour = NULL)) +
  geom_point() +
  geom_smooth(method = "lm") +
  ggtitle("Title", "Subtitle")

## ------------------------------------------------------------------------
ggplot(pp(100), aes(x = x, y = y, fill = z)) +
  geom_tile() +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8) +
  scale_fill_gradient()

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8) +
  scale_fill_gradient2(midpoint = 20)

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, fill = z)) +
  geom_tile(width = 0.8, height = 0.8)

## ------------------------------------------------------------------------
ggplot(pp(20), aes(x = x, y = y, colour = z)) +
  geom_point() +
  scale_colour_gradient()

## ------------------------------------------------------------------------
ggplot(
  df,
  aes(colour = group, y = resp, x = trt, ymax = resp + se, ymin = resp - se)
) +
  geom_point() +
  geom_errorbar(width = 0.2)

## ------------------------------------------------------------------------
ggplot(testgrid, aes(x = x, y = y, fill = z, label = z)) +
  geom_tile(width = 0.7, height = 0.7) +
  geom_text() +
  coord_fixed()

