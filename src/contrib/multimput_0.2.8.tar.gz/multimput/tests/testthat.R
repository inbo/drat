library(testthat)
library(multimput)

test_check("multimput")
