#' inla
#'
#' the inla class is defined in the INLA package
#' @name inla-class
#' @seealso \link[INLA]{inla}
#' @importFrom methods setOldClass
#' @exportClass inla
setOldClass("inla")
