# INBOmd 0.4.1.1 (2017-12-06)

- `inbo_rapport()` now handles UTF-8 strings (like éëèï...) correctly
- the package now displays at warning message at startup about the configuration
