INBOtheme
=========

| Branch | Build status | Code coverage |
| ------ | ------------ | ------------- |
| Master | [![wercker status](https://app.wercker.com/status/31867a7555c3d4bb6a8ba6c7c9994b27/s/master "wercker status")](https://app.wercker.com/project/byKey/31867a7555c3d4bb6a8ba6c7c9994b27) | [![codecov](https://codecov.io/gh/inbo/INBOtheme/branch/master/graph/badge.svg)](https://codecov.io/gh/inbo/INBOtheme) |
| Develop | [![wercker status](https://app.wercker.com/status/31867a7555c3d4bb6a8ba6c7c9994b27/s/develop "wercker status")](https://app.wercker.com/project/byKey/31867a7555c3d4bb6a8ba6c7c9994b27) | [![codecov](https://codecov.io/gh/inbo/INBOtheme/branch/develop/graph/badge.svg)](https://codecov.io/gh/inbo/INBOtheme) |

A collection of ggplot2 themes. Install from Github with:

```R
# install.packages("devtools")
devtools::install_github("inbo/INBOtheme")
```
