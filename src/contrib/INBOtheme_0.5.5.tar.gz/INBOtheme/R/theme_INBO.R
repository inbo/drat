#' This function was removed from INBOtheme
#'
#'Use theme_inbo() instead
#' @rdname defunct
#' @param ... ignored
#' @export
theme_INBO <- function(...) {
  .Defunct("theme_inbo")
}
