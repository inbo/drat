context("defunct")
expect_error(
  theme_set(theme_INBO()),
  "'theme_INBO' is defunct."
)
