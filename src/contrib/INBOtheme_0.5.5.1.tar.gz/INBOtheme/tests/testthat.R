library(testthat)
library(INBOtheme)

test_check("INBOtheme")
